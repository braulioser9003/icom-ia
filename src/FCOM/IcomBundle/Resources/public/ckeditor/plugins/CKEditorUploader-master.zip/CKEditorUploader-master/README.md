Upload script for CKEditor

Introduction
This is a basic set of scripts in C#, Classic Asp, ColdFusion, PHP and Vb.Net to implement quick file uploads in CKEditor as described in its documentation.

Please, refer to the docs/install.html file in order to learn how to use it.

These scripts are provided "as is", I'm not responsible for any problem due to their usage or misconfiguration.

